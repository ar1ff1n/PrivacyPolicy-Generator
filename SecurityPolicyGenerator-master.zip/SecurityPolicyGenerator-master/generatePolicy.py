
import jinja2
import configparser
import os

# Set jinja2 environment.
templateLoader = jinja2.FileSystemLoader(searchpath="./templates/")
templateEnv = jinja2.Environment(loader=templateLoader)

# Import user variables from a config .ini file
configuration_parser = configparser.ConfigParser()
configuration_parser.read('variables.ini', encoding='utf-8-sig')
variable_dictionary = configuration_parser['Company data']

# Check for empty variables
required_variables = [
    'company',
    'companys',
    'number_of_customers',
    'number_of_customers_single_point',
    'country',
    'system_hardening_specification',
    'bcm_threats_list',
    'responsible_cert',
    'list_of_technically_accepted_authentication_solutions',
    'company_worker_abbreviation',
    'allowed_networks',
    'trusted_windows_domain',
    'password_security_rule',
    'identity_and_access_management_standard',
    'link_to_the_company_webpage',
    'link_to_the_resonsible_disclosure_page',
    'abuse_desk_service_name',
    'company_email_domain',
    'company_domain',
    'physical_access_control_specification',
    'physical_security_of_technical_buildings_specification',
    'company_time_zone',
    'maximum_days_storage_retention',
    'company_abuse_report_email_address',
    'company_preferred_list_of_cryptographic_algorithms',
    'company_cryptographic_algorithms_guide',
    'company_logging_guidelines',
    'document_scoping_bcm',
    'bcm_ia_guideline',
    'requirement_selection_document'
]

empty_variables = [var for var in required_variables if not variable_dictionary.get(var)]
if empty_variables:
    print("The following variables are empty: {}".format(', '.join(empty_variables)))
    print("Please provide values for these variables in the 'variables.ini' file.")
    exit(1)

# Create output directory if it doesn't exist
output_directory = './output'
if not os.path.exists(output_directory):
    os.makedirs(output_directory)

# Iterate over template files
list_of_directories = os.listdir('./templates/')
for template_file in list_of_directories:
    template = templateEnv.get_template(template_file)
    output_text = template.render(variable_dictionary).encode('utf-8')
    output_file_path = os.path.join(output_directory, '{}_{}'.format(variable_dictionary['company'], template_file))
    with open(output_file_path, 'wb') as html_file:
        html_file.write(output_text)

print("Successfully generated {} security policies!".format(variable_dictionary['company']))

