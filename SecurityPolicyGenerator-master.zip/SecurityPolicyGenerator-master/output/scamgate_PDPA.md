PDPA Policy

1. Introduction

This PDPA Policy outlines how  ("us", "we", or "our") collects, uses, and discloses personal data that we obtain from users of our website.

2. Collection and Use of Personal Data

We may collect and use personal data for the following purposes:

-  Account Registration: When users register an account on our website, we collect personal data such as name, email address, and contact information to facilitate account management and communication.
- Order Processing and Delivery: If users place an order on our website, we collect personal data such as shipping address and payment details to process and deliver the order.
- Customer Support: We may collect personal data when users contact us for customer support, including name, email address, and details of the inquiry or issue.
- Marketing Communication: With user consent, we may collect personal data such as email address to send promotional materials, newsletters, or updates about our products and services.

3. Disclosure of Personal Data

We may disclose personal data to third parties in the following circumstances:

- Service Providers: We may engage third-party service providers who process personal data on our behalf to facilitate order processing, delivery, customer support, or marketing activities. These service providers are bound by contractual obligations to handle personal data securely and confidentially.
- Legal Requirements: We may disclose personal data if required to do so by law or in response to valid legal requests, such as court orders or government regulations.

4. Data Security

We take reasonable precautions to protect personal data from unauthorized access, use, or disclosure. We implement appropriate security measures, including administrative, technical, and physical safeguards, to ensure the confidentiality, integrity, and availability of personal data.

5. Data Retention

We retain personal data for as long as necessary to fulfill the purposes for which it was collected and to comply with legal obligations. When personal data is no longer required, we will securely dispose of or anonymize it.

6. Data Subject Rights

Data subjects have the following rights regarding their personal data:

- Access: Data subjects can request access to their personal data held by  and obtain information about how it is processed.
- Rectification: Data subjects can request the correction of inaccurate or incomplete personal data.
- Erasure: Data subjects can request the deletion of personal data, subject to legal obligations and legitimate business purposes.
- Restriction: Data subjects can request the restriction of processing their personal data under certain circumstances.
- Objection: Data subjects can object to the processing of their personal data in specific situations.
- Data Portability: Data subjects can request a copy of their personal data in a structured, commonly used, and machine-readable format.

7. Contact Us

If you have any questions about our PDPA Policy or would like to exercise your data subject rights, please contact us at:

- Email: 
- Phone: 
